package org.g9project4.board.services;

public class BoardInfoService {
}
