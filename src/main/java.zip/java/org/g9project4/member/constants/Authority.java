package org.g9project4.member.constants;

public enum Authority {
    ALL,
    USER,
    ADMIN
}
