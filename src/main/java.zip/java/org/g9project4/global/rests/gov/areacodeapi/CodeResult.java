package org.g9project4.global.rests.gov.areacodeapi;

import lombok.Data;

@Data
public class CodeResult {
    private CodeResponse response;
}
