package org.g9project4.global.rests.gov.detailapi;

import lombok.Data;

@Data
public class DetailResult {
    private DetailResponse response;
}
