package org.g9project4.global.rests.gov.detailapi;

import lombok.Data;

import java.util.List;
@Data
public class DetailItems {
    List<DetailItem> item;
}
