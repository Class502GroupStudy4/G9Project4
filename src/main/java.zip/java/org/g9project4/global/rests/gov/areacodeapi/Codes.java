package org.g9project4.global.rests.gov.areacodeapi;

import lombok.Data;

import java.util.List;

@Data
public class Codes {
    private List<Code> item;
}
