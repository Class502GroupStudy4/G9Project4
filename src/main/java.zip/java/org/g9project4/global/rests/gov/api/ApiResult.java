package org.g9project4.global.rests.gov.api;

import lombok.Data;

@Data
public class ApiResult {
    private ApiResponse response;
}
